/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package shapes;

import java.awt.Graphics;
import java.awt.Point;


/**
 *
 * @author Samsung
 */
public abstract class AbstractShapeClass implements Shape,Moveable {

    private java.awt.Point position;
    private java.awt.Color borderColor;
    private java.awt.Color fillColor;
    private java.awt.Point draggingPoint;

    public AbstractShapeClass(java.awt.Point position)
    {
        this.position=position;

    }    
    @Override
    public final void setPosition(java.awt.Point position) {
        this.position = position;
    }

    @Override
    public java.awt.Point getPosition() {
        return this.position;
    }

    @Override
    public void setColor(java.awt.Color color) {
        borderColor = color;
    }

    @Override
    public java.awt.Color getColor() {
        return borderColor;
    }

    @Override
    public void setFillColor(java.awt.Color color) {
        fillColor = color;
    }

    @Override
    public java.awt.Color getFillColor() {
        return fillColor;
    }
    
    @Override
    public abstract void draw(Graphics canvas);

    @Override
    public void setDraggingPoint(Point point) {
        this.draggingPoint=point;
    }

    @Override
    public Point getDraggingPoint() {
        return draggingPoint;
    }

    @Override
    public abstract boolean contains(Point point);
 
    @Override
    public abstract void moveTo(Point point);
    
}
