/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package shapes;

import java.awt.BasicStroke;
import java.awt.Graphics2D;
import java.awt.Point;
import static java.lang.Math.abs;
import static java.lang.Math.pow;

/**
 *
 * @author Samsung
 */
public class StraightLine extends AbstractShapeClass {

    private final java.awt.Point position2;

    public StraightLine(java.awt.Point position, java.awt.Point position2) {
        super(position);
        this.position2 = position2;
    }

    @Override
    public void draw(java.awt.Graphics canvas) {
        canvas.setColor(getColor());
        Graphics2D g2 = (Graphics2D) canvas;
        g2.setStroke(new BasicStroke(4));
        canvas.drawLine(getPosition().x, getPosition().y, position2.x, position2.y);
    }

    @Override
    public boolean contains(Point point) {
        //double Diff1= point.y-getPosition().y / point.x-getPosition().x;
        //double Diff2=position2.y-point.y /position2.x-point.x ;
        //return Diff1==Diff2;
//        int xDiff=position2.x-getPosition().x;
//        int yDiff=position2.y-getPosition().y;
//        long length =(long) (pow(xDiff,2)+pow(yDiff,2));
        double length= Math.sqrt(frontend.Helpers.DistanceSquareToLine(getPosition().x, getPosition().y, position2.x, position2.y, point.x, point.y));
        return abs(length) <= 2 * Double.MIN_VALUE;
    }

    @Override
    public void moveTo(Point point) {
        this.setPosition(getDraggingPoint());
        position2.translate(point.x - position2.x, point.y - position2.y);
    }
}
