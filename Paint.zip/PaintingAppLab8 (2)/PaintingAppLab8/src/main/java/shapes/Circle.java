/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package shapes;

import java.awt.Point;
import static java.lang.Math.abs;
import static java.lang.Math.pow;


/**
 *
 * @author Samsung
 */
public class Circle extends AbstractShapeClass {

    private final int radius;

    public Circle(java.awt.Point position, int radius) {
        super(position);
        this.radius=radius;
    }

    @Override
    public void draw(java.awt.Graphics canvas) {
        int centerX = getPosition().x - radius;
        int centerY = getPosition().y - radius;
        canvas.setColor(getColor());
        canvas.drawOval(centerX, centerY, 2 * radius, 2 * radius);
        canvas.setColor(getFillColor());
        canvas.fillOval(centerX, centerY, 2 * radius, 2 * radius);
    }

    @Override
    public boolean contains(Point point) {
            double distance;
            double xDiff=pow((abs(point.x - getPosition().x)),2);
            double yDiff=pow((abs(point.y - getPosition().y)),2);
            distance=Math.sqrt(xDiff+yDiff);
            System.out.println(xDiff+"   "+yDiff+"   "+distance);
            return distance <= radius;
    }

    @Override
    public void moveTo(Point point) {
        setPosition(getDraggingPoint());
    }

}
