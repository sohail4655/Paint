/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package shapes;

import java.awt.Point;


/**
 *
 * @author Samsung
 */
public class Triangle extends AbstractShapeClass {
    
    private final java.awt.Point position2;
    private final java.awt.Point position3;
    private int[] xPoints;
    private int[] yPoints;
    public Triangle(java.awt.Point position, java.awt.Point position2,java.awt.Point position3) {
        super(position);
        this.position2= position2;
        this.position3= position3;
        
        
    }


    @Override
    public void draw(java.awt.Graphics canvas) {
        canvas.setColor(getColor());
        xPoints= new int[]{this.getPosition().x,position2.x,position3.x};
        yPoints= new int[]{this.getPosition().y,position2.y,position3.y};
        canvas.drawPolygon(xPoints, yPoints, 3);
        canvas.setColor(getFillColor());
        canvas.fillPolygon(xPoints, yPoints, 3);
    }

    @Override
    public boolean contains(Point point) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void moveTo(Point point) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
