/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package shapes;

import java.awt.Point;

/**
 *
 * @author Samsung
 */
public class Rectangle extends AbstractShapeClass {

    private final int length;
    private final int width;

    public Rectangle(java.awt.Point position, int length, int width) {
        super(position);
        this.length = length;
        this.width = width;

    }

    @Override
    public void draw(java.awt.Graphics canvas) {
        canvas.setColor(getColor());
        canvas.drawRect(getPosition().x, getPosition().y, this.width, this.length);
        canvas.setColor(getFillColor());
        canvas.fillRect(getPosition().x, getPosition().y, this.width, this.length);

    }

    @Override
    public boolean contains(Point point) {
        boolean inX = point.x <= getPosition().x + width;
        boolean inY = point.y <= getPosition().y + length;
        return inX&&inY;
    }

    @Override
    public void moveTo(Point point) {
        setPosition(getDraggingPoint());
    }

}
