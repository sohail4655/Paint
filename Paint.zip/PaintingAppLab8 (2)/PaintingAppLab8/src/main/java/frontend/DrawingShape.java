/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package frontend;

import shapes.Shape;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.util.ArrayList;
import javax.swing.JPanel;

/**
 *
 * @author Samsung
 */
public class DrawingShape extends JPanel implements DrawingEngine {

    private final ArrayList< shapes.Shape> shapes;
    private shapes.AbstractShapeClass movingShape;

    public DrawingShape() {
        shapes = new ArrayList();

        ClickListener cListener = new ClickListener();
        this.addMouseListener(cListener);

        DragListener dListner = new DragListener();
        this.addMouseMotionListener(dListner);
    }

    @Override
    public void paintComponent(Graphics canvas) {
        super.paintComponent(canvas);
        for (shapes.Shape s : shapes) {
            s.draw(canvas);
        }
    }

    @Override
    public void addShape(Shape shape) {
        shapes.add(shape);
        refresh(null);

    }

    @Override
    public void removeShape(Shape shape) {
        shapes.remove(shape);
        refresh(null);
    }

    @Override
    public Shape[] getShapes() {
        return shapes.toArray(shapes.Shape[]::new);
    }

    @Override
    public void refresh(Graphics canvas) {
        repaint();
    }

    private class ClickListener extends MouseAdapter {

        @Override
        public void mousePressed(MouseEvent evt) {
            Point currentPoint = evt.getPoint();
            System.out.println("Point" + currentPoint.x + "  " + currentPoint.y);
            for (shapes.Shape s : shapes) {
                shapes.AbstractShapeClass currentShape = (shapes.AbstractShapeClass) s;
                if (currentShape.contains(currentPoint)) {
                    movingShape=currentShape;
                    System.out.println("yes");
                    break;
                }
            }
        }
    }

    private class DragListener extends MouseMotionAdapter {

        @Override
        public void mouseDragged(MouseEvent evt) {
            Point newPoint = evt.getPoint();
            if (movingShape != null) {
                movingShape.setDraggingPoint(newPoint);
                movingShape.moveTo(movingShape.getDraggingPoint());
                refresh(null);
            }
        }
    }

}
